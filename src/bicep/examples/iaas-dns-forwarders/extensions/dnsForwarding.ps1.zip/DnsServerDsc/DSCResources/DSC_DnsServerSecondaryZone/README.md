# Description

The DnsServerSecondaryZone DSC resource manages a standalone file-backed
secondary zone on a Domain Name System (DNS) server. Secondary zones allow
client machine in primary DNS zones to do DNS resolution of machines in the
secondary DNS zone.
